from setuptools import setup, find_packages

setup(
name='AgroEcoMetrics',
version='0.0.1',
author='Scarlett Olson',
author_email='nwolson@wisc.edu',
description='A short description of your package',
packages=find_packages(),
classifiers=[
'Programming Language :: Python :: 3',
'License :: OSI Approved :: MIT License',
'Operating System :: OS Independent',
],
python_requires='>=3.6',
)